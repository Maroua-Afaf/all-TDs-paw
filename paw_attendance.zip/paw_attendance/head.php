<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Attendance</title>
  <link rel="stylesheet" href="style.css">
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
</head>

<body>
<div class="layout">

  <aside class="sidebar">
    <div class="brand">
      <img src="assets/icons/dashboard.png" class="icon" alt="">
      <div class="brand-title">Attendance</div>
    </div>

    <nav class="nav">
      <a href="dashboard.php"><img class="icon" src="assets/icons/dashboard.png"> Dashboard</a>

      <div class="nav-section">Students</div>
      <a href="add_student.php"><img class="icon" src="assets/icons/add.png"> Add student</a>
      <a href="list_students.php"><img class="icon" src="assets/icons/list.png"> List students</a>

      <div class="nav-section">Sessions</div>
      <a href="create_session.php"><img class="icon" src="assets/icons/session.png"> Create session</a>
      <a href="list_sessions.php"><img class="icon" src="assets/icons/list_sessions.png"> Sessions</a>

      <div class="nav-section">Attendance</div>
      <a href="take_attendance.php"><img class="icon" src="assets/icons/attendance.png"> Take attendance</a>
    </nav>

  </aside>

  <main class="content">
    <header class="topbar">
      <button id="toggle-sidebar" class="hamburger">
        <img src="assets/icons/menu.png" class="menu-icon">
      </button>

      <h1 id="page-title"></h1>
    </header>

    <div class="container">
