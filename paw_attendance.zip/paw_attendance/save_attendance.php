<?php
require "db.php";

$session_id = $_POST['session_id'] ?? null;
if(!$session_id) die("Invalid session.");

$present = $_POST['present'] ?? [];
$participated = $_POST['participated'] ?? [];

$students = $pdo->query("SELECT id FROM students")->fetchAll();

foreach($students as $s){
    $id = $s['id'];

    $p = isset($present[$id]) ? 1 : 0;
    $pa = isset($participated[$id]) ? 1 : 0;

    $stmt = $pdo->prepare("
        INSERT INTO attendance (session_id, student_id, present, participated)
        VALUES (?,?,?,?)
        ON DUPLICATE KEY UPDATE present = VALUES(present),
                                participated = VALUES(participated)
    ");

    $stmt->execute([$session_id, $id, $p, $pa]);
}

header("Location: take_attendance.php?session_id=$session_id&saved=1");
exit;
