<?php
require_once 'db.php';
include 'head.php';

$sessions = $pdo->query("SELECT * FROM sessions ORDER BY session_date DESC")->fetchAll();
?>
<div class="card-large">
  <div style="display:flex;justify-content:space-between;align-items:center">
    <h2>Sessions</h2>
    <a class="btn" href="create_session.php">Create session</a>
  </div>

  <table class="table">
    <thead><tr><th>#</th><th>Date</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody>
      <?php if(empty($sessions)): ?>
        <tr><td colspan="4" class="muted">No sessions yet</td></tr>
      <?php else: foreach($sessions as $s): ?>
        <tr>
          <td><?= $s['id'] ?></td>
          <td><?= htmlspecialchars($s['session_date']) ?></td>
          <td><?= htmlspecialchars($s['status']) ?></td>
          <td class="actions">
            <?php if($s['status'] === 'open'): ?>
              <a class="btn ghost" href="take_attendance.php?session_id=<?= $s['id'] ?>">Take</a>
              <a class="btn" href="close_session.php?id=<?= $s['id'] ?>" onclick="return confirm('Close session?')">Close</a>
            <?php else: ?>
              <a class="btn ghost" href="take_attendance.php?session_id=<?= $s['id'] ?>">View</a>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<?php include 'footer.php'; ?>
