<?php
// footer.php
?>
    </div> <!-- container -->
  </main>
</div> <!-- layout -->
<script src="script.js"></script>
</body>
</html>
