<?php
require_once __DIR__ . '/db.php';

if (!session_id()) session_start();

// Escape output
function e($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

// Flash functions
function flash_set($type, $message) {
    $_SESSION['flash'][$type][] = $message;
}
function flash_display() {
    if (!empty($_SESSION['flash'])) {
        foreach ($_SESSION['flash'] as $type => $messages) {
            foreach ($messages as $msg) {
                echo "<div class='flash {$type}'>" . e($msg) . "</div>";
            }
        }
        unset($_SESSION['flash']);
    }
}

// --------------------------------------------------
// 1. Determine session automatically
// --------------------------------------------------
$session_id = isset($_GET['session_id']) ? (int)$_GET['session_id'] : 0;

if (!$session_id) {

    // Try last OPEN session
    $s = $pdo->query("SELECT * FROM sessions WHERE closed_at IS NULL ORDER BY id DESC LIMIT 1")->fetch();

    if ($s) {
        $session_id = $s['id'];
    } else {
        // Try last ANY session (even closed)
        $s = $pdo->query("SELECT * FROM sessions ORDER BY id DESC LIMIT 1")->fetch();
        if ($s) {
            $session_id = $s['id'];
        } else {
            echo "<div class='flash error'>No sessions found. Create one first.</div>";
            exit;
        }
    }
}

// --------------------------------------------------
// 2. Fetch session
// --------------------------------------------------
$stmt = $pdo->prepare("SELECT * FROM sessions WHERE id = ?");
$stmt->execute([$session_id]);
$session = $stmt->fetch();

if (!$session) {
    echo "<div class='flash error'>Session not found.</div>";
    exit;
}

// --------------------------------------------------
// 3. Handle save attendance POST
// --------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $present = $_POST['present'] ?? [];
    $participated = $_POST['participated'] ?? [];

    // Fetch all student IDs
    $student_ids = $pdo->query("SELECT id FROM students")->fetchAll(PDO::FETCH_COLUMN);

    foreach ($student_ids as $sid) {

        $p  = isset($present[$sid]) ? 1 : 0;
        $pa = isset($participated[$sid]) ? 1 : 0;

        $up = $pdo->prepare("
            INSERT INTO attendance (session_id, student_id, present, participated)
            VALUES (?,?,?,?)
            ON DUPLICATE KEY UPDATE 
                present = VALUES(present),
                participated = VALUES(participated)
        ");
        $up->execute([$session_id, $sid, $p, $pa]);
    }

    flash_set('success', 'Attendance saved successfully!');
    header("Location: take_attendance.php?session_id=" . $session_id);
    exit;
}

// --------------------------------------------------
// 4. Fetch students
// --------------------------------------------------
$students = $pdo->query("SELECT * FROM students ORDER BY firstname")->fetchAll();

// --------------------------------------------------
// 5. Fetch existing attendance
// --------------------------------------------------
$att = $pdo->prepare("SELECT student_id, present, participated FROM attendance WHERE session_id = ?");
$att->execute([$session_id]);

$existing = [];
foreach ($att->fetchAll() as $r) {
    $existing[$r['student_id']] = [
        'present' => $r['present'],
        'participated' => $r['participated']
    ];
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Take Attendance</title>

<style>
body {
    font-family: Arial, sans-serif;
    padding: 20px;
}

.flash.success { 
    color: #0a9200; 
    background: #d9ffd8;
    padding: 10px;
    margin-bottom: 10px;
    border-radius: 6px;
}
.flash.error { 
    color: #b10000; 
    background: #ffd8d8;
    padding: 10px;
    margin-bottom: 10px;
    border-radius: 6px;
}

.table { 
    border-collapse: collapse; 
    width: 100%; 
    margin-top: 20px;
}
.table th, .table td { 
    border: 1px solid #ccc; 
    padding: 10px; 
}
.table th {
    background: #f5f5f5;
}

.btn {
    padding: 10px 20px;
    background: #4a80ff;
    color: white;
    text-decoration: none;
    border: none;
    cursor: pointer;
    margin-top: 15px;
    display: inline-block;
    border-radius: 6px;
}

.btn:hover {
    background: #1f55d0;
}

</style>
</head>
<body>

<h2>Attendance — Session #<?= e($session['id']) ?> (Opened: <?= e($session['opened_at']) ?>)</h2>

<?php flash_display(); ?>

<form method="POST">

<table class="table">
    <thead>
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Present</th>
            <th>Participated</th>
        </tr>
    </thead>

    <tbody>
    <?php foreach ($students as $i => $s): 
        $id  = $s['id'];
        $ex  = $existing[$id] ?? ['present' => 0, 'participated' => 0];
    ?>
        <tr>
            <td><?= $i + 1 ?></td>
            <td><?= e($s['firstname'] . " " . $s['lastname']) ?></td>

            <td style="text-align:center">
                <input type="checkbox" name="present[<?= $id ?>]" <?= $ex['present'] ? "checked" : "" ?>>
            </td>

            <td style="text-align:center">
                <input type="checkbox" name="participated[<?= $id ?>]" <?= $ex['participated'] ? "checked" : "" ?>>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<button class="btn" type="submit">Save Attendance</button>

</form>

</body>
</html>
