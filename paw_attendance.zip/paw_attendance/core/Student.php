<?php
// core/Student.php
class Student {
  private $pdo;
  public function __construct(PDO $pdo){ $this->pdo = $pdo; }

  public function all(){ return $this->pdo->query("SELECT * FROM students ORDER BY lastname, firstname")->fetchAll(); }
  public function find($id){ $st = $this->pdo->prepare("SELECT * FROM students WHERE id = ?"); $st->execute([$id]); return $st->fetch(); }
  public function create($mat,$first,$last,$email){ $st = $this->pdo->prepare("INSERT INTO students (matricule, firstname, lastname, email) VALUES (?,?,?,?)"); $st->execute([$mat,$first,$last,$email]); return $this->pdo->lastInsertId(); }
  public function update($id,$mat,$first,$last,$email){ $st=$this->pdo->prepare("UPDATE students SET matricule=?, firstname=?, lastname=?, email=? WHERE id=?"); return $st->execute([$mat,$first,$last,$email,$id]); }
  public function delete($id){ $st=$this->pdo->prepare("DELETE FROM students WHERE id=?"); return $st->execute([$id]); }
}
