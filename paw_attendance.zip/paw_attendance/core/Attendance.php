<?php
// core/Attendance.php
class Attendance {
  private $pdo;
  public function __construct(PDO $pdo){ $this->pdo = $pdo; }

  public function getForSession($session_id){
    $st = $this->pdo->prepare("SELECT * FROM attendance WHERE session_id = ?");
    $st->execute([$session_id]); return $st->fetchAll();
  }

  public function saveBulk($session_id, array $rows){
    $this->pdo->beginTransaction();
    $this->pdo->prepare("DELETE FROM attendance WHERE session_id = ?")->execute([$session_id]);
    $ins = $this->pdo->prepare("INSERT INTO attendance (session_id, student_id, present, participated) VALUES (?, ?, ?, ?)");
    foreach($rows as $r) $ins->execute([$session_id, (int)$r['student_id'], (int)$r['present'], (int)$r['participated']]);
    $this->pdo->commit();
    return true;
  }
}
