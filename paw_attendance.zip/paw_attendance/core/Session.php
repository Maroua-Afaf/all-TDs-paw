<?php
// core/Session.php
class SessionModel {
  private $pdo;
  public function __construct(PDO $pdo){ $this->pdo = $pdo; }
  public function all(){ return $this->pdo->query("SELECT * FROM sessions ORDER BY session_date DESC")->fetchAll(); }
  public function create($date){ $st=$this->pdo->prepare("INSERT INTO sessions (session_date,status) VALUES (?, 'open')"); $st->execute([$date]); return $this->pdo->lastInsertId(); }
  public function find($id){ $st=$this->pdo->prepare("SELECT * FROM sessions WHERE id=?"); $st->execute([$id]); return $st->fetch(); }
  public function close($id){ $st=$this->pdo->prepare("UPDATE sessions SET status='closed' WHERE id=?"); return $st->execute([$id]); }
}
