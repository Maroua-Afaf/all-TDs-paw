<?php require "db.php"; require "head.php"; ?>

<h2 class="page-title">Add Student</h2>

<form method="POST">
  <label>Matricule</label>
  <input type="text" name="matricule" required>

  <label>First Name</label>
  <input type="text" name="firstname" required>

  <label>Last Name</label>
  <input type="text" name="lastname" required>

  <label>Email</label>
  <input type="email" name="email">

  <button class="btn" name="add">Add</button>
</form>

<?php
if(isset($_POST['add'])){
    $stmt=$pdo->prepare("INSERT INTO students (matricule,firstname,lastname,email) VALUES (?,?,?,?)");
    $stmt->execute([$_POST['matricule'],$_POST['firstname'],$_POST['lastname'],$_POST['email']]);
    echo "<p class='success'>Student Added!</p>";
}
?>

<?php require "footer.php"; ?>
