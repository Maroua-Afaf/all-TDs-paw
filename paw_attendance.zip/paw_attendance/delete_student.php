<?php
require_once 'db.php';
$id = (int)($_GET['id'] ?? 0);
if($id){
  $stmt = $pdo->prepare("DELETE FROM students WHERE id = ?");
  $stmt->execute([$id]);
}
header('Location: list_students.php');
exit;
