<?php
require_once 'db.php';
include 'head.php';

$errors=[]; $success=null;

if($_SERVER['REQUEST_METHOD']==='POST'){
  $date = trim($_POST['session_date'] ?? '');
  if(!$date) $errors[]="Date required";
  if(empty($errors)){
    $stmt=$pdo->prepare("INSERT INTO sessions (session_date,status) VALUES (?, 'open')");
    $stmt->execute([$date]);
    $success="Session created.";
  }
}
?>

<div class="card-large" style="max-width:420px">
  <h2>Create session</h2>

  <?php foreach($errors as $e) echo "<div class='error'>$e</div>"; ?>
  <?php if($success) echo "<div class='success'>$success</div>"; ?>

  <form method="post">
    <label>Session date</label>
    <input type="date" name="session_date" class="form-input" required>

    <div class="form-actions">
      <button class="btn" type="submit">Create</button>
      <a class="btn ghost" href="list_sessions.php">Cancel</a>
    </div>
  </form>
</div>

<?php include 'footer.php'; ?>
