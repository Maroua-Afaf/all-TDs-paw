<?php
require_once 'db.php';
include 'head.php';

$totalStudents = (int)$pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
$totalSessions = (int)$pdo->query("SELECT COUNT(*) FROM sessions")->fetchColumn();
$openSessions = (int)$pdo->query("SELECT COUNT(*) FROM sessions WHERE status='open'")->fetchColumn();

$last = $pdo->query("SELECT id, session_date, status FROM sessions ORDER BY id DESC LIMIT 1")->fetch();

$rs = $pdo->prepare("
  SELECT s.id, s.session_date, s.status, COALESCE(SUM(a.present),0) AS present_count
  FROM sessions s
  LEFT JOIN attendance a ON a.session_id = s.id AND a.present = 1
  GROUP BY s.id
  ORDER BY s.session_date DESC
  LIMIT 8
");
$rs->execute();
$recent = $rs->fetchAll();
?>

<div class="cards">

  <div class="card">
    <div class="card-body">
      <div class="card-title">Students</div>
      <div class="card-value"><?= $totalStudents ?></div>
    </div>
    <div class="card-icon-holder">
      <img src="assets/icons/user.png" class="icon">
    </div>
  </div>

  <div class="card">
    <div class="card-body">
      <div class="card-title">Sessions</div>
      <div class="card-value"><?= $totalSessions ?></div>
    </div>
    <div class="card-icon-holder">
      <img src="assets/icons/session.png" class="icon">
    </div>
  </div>

  <div class="card">
    <div class="card-body">
      <div class="card-title">Open sessions</div>
      <div class="card-value"><?= $openSessions ?></div>
    </div>
    <div class="card-icon-holder">
      <img src="assets/icons/attendance.png" class="icon">
    </div>
  </div>

  <div class="card card-cta">
    <div class="card-body">
      <div class="card-title">Last session</div>
      <?php if($last): ?>
        <div class="card-value"><?= $last['session_date'] ?></div>
        <div class="muted">Status: <?= $last['status'] ?></div>
      <?php else: ?>
        <div class="card-value">—</div>
        <div class="muted">No sessions yet</div>
      <?php endif; ?>
    </div>
    <div class="card-icon-holder">
      <a class="btn" href="create_session.php">Create</a>
    </div>
  </div>

</div>


<div class="bottom">

  <div class="panel-left">
    <h3>Recent activity</h3>

    <table class="recent-table">
      <thead>
        <tr><th>Date</th><th>Status</th><th>Present</th><th>Action</th></tr>
      </thead>
      <tbody>
        <?php if(empty($recent)): ?>
          <tr><td colspan="4" class="muted">No activity yet</td></tr>
        <?php else: foreach($recent as $r): ?>
        <tr>
          <td><?= $r['session_date'] ?></td>
          <td><?= $r['status'] ?></td>
          <td><?= $r['present_count'] ?></td>
          <td>
            <?php if($r['status']==='open'): ?>
              <a class="btn ghost" href="take_attendance.php?session_id=<?= $r['id'] ?>">Take</a>
              <a class="btn" href="close_session.php?id=<?= $r['id'] ?>">Close</a>
            <?php else: ?>
              <a class="btn ghost" href="take_attendance.php?session_id=<?= $r['id'] ?>">View</a>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>

  </div>
</div>

<?php include 'footer.php'; ?>
