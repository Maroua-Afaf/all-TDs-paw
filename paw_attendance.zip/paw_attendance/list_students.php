<?php
require_once 'db.php';
include 'head.php';

$students = $pdo->query("SELECT * FROM students ORDER BY lastname, firstname")->fetchAll();
?>
<div class="card-large">
  <div style="display:flex;justify-content:space-between;align-items:center">
    <h2>Students</h2>
    <a class="btn" href="add_student.php">Add student</a>
  </div>

  <table class="table">
    <thead><tr><th>#</th><th>Matricule</th><th>Name</th><th>Email</th><th>Actions</th></tr></thead>
    <tbody>
      <?php if(empty($students)): ?>
        <tr><td colspan="5" class="muted">No students yet</td></tr>
      <?php else: foreach($students as $s): ?>
        <tr>
          <td><?= $s['id'] ?></td>
          <td><?= htmlspecialchars($s['matricule']) ?></td>
          <td><?= htmlspecialchars($s['firstname'].' '.$s['lastname']) ?></td>
          <td><?= htmlspecialchars($s['email']) ?></td>
          <td class="actions">
            <a class="btn ghost" href="update_student.php?id=<?= $s['id'] ?>">Edit</a>
            <a class="btn" href="delete_student.php?id=<?= $s['id'] ?>" onclick="return confirm('Delete?')">Delete</a>
          </td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<?php include 'footer.php'; ?>
