<?php
// helpers.php

// Escape HTML special characters
function e($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

// Flash messages using session
function flash_set($type, $message) {
    if (!session_id()) session_start();
    $_SESSION['flash'][$type][] = $message;
}

function flash_display() {
    if (!session_id()) session_start();
    if (!empty($_SESSION['flash'])) {
        foreach ($_SESSION['flash'] as $type => $messages) {
            foreach ($messages as $msg) {
                echo "<div class='flash {$type}'>".htmlspecialchars($msg)."</div>";
            }
        }
        unset($_SESSION['flash']);
    }
}
