<?php
// index.php — redirect to dashboard
header('Location: dashboard.php');
exit;
