<?php
require_once 'db.php';
include 'head.php';

$id = (int)($_GET['id'] ?? 0);
if(!$id){ header('Location: list_students.php'); exit; }

$stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
$stmt->execute([$id]);
$student = $stmt->fetch();
if(!$student){ echo "<div class='card-large'>Student not found</div>"; include 'footer.php'; exit; }

$errors = []; $success = null;
if($_SERVER['REQUEST_METHOD'] === 'POST'){
  $matricule = trim($_POST['matricule'] ?? '');
  $firstname = trim($_POST['firstname'] ?? '');
  $lastname = trim($_POST['lastname'] ?? '');
  $email = trim($_POST['email'] ?? '');
  if($firstname === '' || $lastname === '') $errors[] = "First and last name required";
  if($email && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Invalid email";
  if(empty($errors)){
    $u = $pdo->prepare("UPDATE students SET matricule=?, firstname=?, lastname=?, email=? WHERE id=?");
    $u->execute([$matricule, $firstname, $lastname, $email, $id]);
    $success = "Updated";
    // refresh data
    $stmt->execute([$id]);
    $student = $stmt->fetch();
  }
}
?>
<div class="card-large">
  <h2>Edit student</h2>
  <?php foreach($errors as $e) echo "<div class='error'>$e</div>"; ?>
  <?php if($success) echo "<div class='success'>$success</div>"; ?>

  <form method="post" class="form-grid">
    <label>Matricule <input name="matricule" value="<?= htmlspecialchars($student['matricule']) ?>" /></label>
    <label>First name <input name="firstname" value="<?= htmlspecialchars($student['firstname']) ?>" required /></label>
    <label>Last name <input name="lastname" value="<?= htmlspecialchars($student['lastname']) ?>" required /></label>
    <label>Email <input name="email" value="<?= htmlspecialchars($student['email']) ?>" /></label>
    <div class="form-actions">
      <button class="btn" type="submit">Save</button>
      <a class="btn ghost" href="list_students.php">Back</a>
    </div>
  </form>
</div>

<?php include 'footer.php'; ?>
