<?php
require_once 'db.php';
$id = (int)($_GET['id'] ?? 0);
if($id){
  $stmt = $pdo->prepare("UPDATE sessions SET status='closed' WHERE id = ?");
  $stmt->execute([$id]);
}
header('Location: list_sessions.php');
exit;
