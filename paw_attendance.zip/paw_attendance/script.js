// script.js — small helpers
$(function(){
  $('#toggle-sidebar').on('click', function(){
    $('.sidebar').toggle();
  });

  const p = location.pathname.split('/').pop();
  const mapping = {
    'dashboard.php':'Dashboard',
    'add_student.php':'Add student',
    'list_students.php':'Students',
    'create_session.php':'Create session',
    'list_sessions.php':'Sessions',
    'take_attendance.php':'Take attendance'
  };
  $('#page-title').text(mapping[p] || 'PAW Attendance');

  // soft hover animation for quick-actions
  $('.quick-actions .action').hover(function(){ $(this).css('transform','translateX(6px)') }, function(){ $(this).css('transform','translateX(0)') });
});
