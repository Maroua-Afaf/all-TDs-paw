/* =======================================================
   Helper functions
======================================================= */
function getTbody() {
    return document.getElementById("attendanceTable").tBodies[0];
}

function computeRowCounts(row) {
    let abs = 0, pres = 0, part = 0;

    // S1..S6
    for (let i = 4; i <= 9; i++) {
        const cb = row.cells[i].querySelector("input");
        if (cb && cb.checked) pres++; else abs++;
    }

    // P1..P6
    for (let i = 10; i <= 15; i++) {
        const cb = row.cells[i].querySelector("input");
        if (cb && cb.checked) part++;
    }

    return { absences: abs, presences: pres, participation: part };
}

/* =======================================================
   EXO 1 — Calculate
======================================================= */
function updateAllRows() {
    const tbody = getTbody();
    for (let row of tbody.rows) {
        const { absences } = computeRowCounts(row);

        row.classList.remove("row-green", "row-yellow", "row-red");

        if (absences < 3) row.classList.add("row-green");
        else if (absences <= 4) row.classList.add("row-yellow");
        else row.classList.add("row-red");

        const msg = row.cells[16];
        if (absences < 3) msg.textContent = "Good attendance – Excellent participation";
        else if (absences <= 4) msg.textContent = "Warning – attendance low";
        else msg.textContent = "Excluded – too many absences";
    }
}

document.getElementById("calculateBtn").onclick = updateAllRows;

/* =======================================================
   EXO 2+3 — Add Student
======================================================= */
document.getElementById("studentForm").addEventListener("submit", function (e) {
    e.preventDefault();

    document.querySelectorAll(".error").forEach(e => e.textContent = "");
    document.getElementById("successMsg").textContent = "";

    const id = studentId.value.trim();
    const last = lastName.value.trim();
    const first = firstName.value.trim();
    const email = document.getElementById("email").value.trim();

    let ok = true;
    if (!/^\d+$/.test(id)) { errorId.textContent = "Invalid ID"; ok = false; }
    if (!/^[A-Za-z]+$/.test(last)) { errorLast.textContent = "Invalid name"; ok = false; }
    if (!/^[A-Za-z]+$/.test(first)) { errorFirst.textContent = "Invalid name"; ok = false; }
    if (!/^\S+@\S+\.\S+$/.test(email)) { errorEmail.textContent = "Invalid email"; ok = false; }

    if (!ok) return;

    const tbody = getTbody();
    const r = tbody.insertRow();

    r.innerHTML = `
        <td>${id}</td>
        <td>${last}</td>
        <td>${first}</td>
        <td>Advanced Web</td>
        ${"<td><input type='checkbox'></td>".repeat(6)}
        ${"<td><input type='checkbox'></td>".repeat(6)}
        <td></td>
    `;

    document.getElementById("successMsg").textContent = "Student added!";
    this.reset();
});

/* =======================================================
   EXO 4 — Show Report + Chart
======================================================= */
let chartInstance = null;

function drawReportChart(total, present, participated, excellent) {
    const ctx = document.getElementById("reportChart");

    if (chartInstance) chartInstance.destroy();

    chartInstance = new Chart(ctx, {
        type: "bar",
        data: {
            labels: ["Students", "Present", "Participation", "Excellent"],
            datasets: [{
                data: [total, present, participated, excellent],
                backgroundColor: ["#4285F4", "#34A853", "#FBBC05", "#EA4335"],
                hoverBackgroundColor: ["#2b63d9", "#2a8b46", "#d5a204", "#b92f22"]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
        }
    });
}

document.getElementById("showReportBtn").onclick = function () {
    updateAllRows();

    const tbody = getTbody();
    let total = tbody.rows.length, pres = 0, part = 0, excellent = 0;

    for (let row of tbody.rows) {
        const x = computeRowCounts(row);
        pres += x.presences;
        part += x.participation;
        if (x.absences < 3) excellent++;
    }

    reportResults.innerHTML = `
        <p><strong>Total Students:</strong> ${total}</p>
        <p><strong>Total Present:</strong> ${pres}</p>
        <p><strong>Total Participation:</strong> ${part}</p>
        <p><strong>Excellent (&lt;3 abs):</strong> ${excellent}</p>
    `;

    drawReportChart(total, pres, part, excellent);
};

/* =======================================================
   EXO 5 — Hover
======================================================= */
$("#attendanceTable tbody").on("mouseenter", "tr", function () {
    $(this).css("background", "#e4ecff");
});
$("#attendanceTable tbody").on("mouseleave", "tr", function () {
    $(this).css("background", "");
});

/* =======================================================
   EXO 6 — Highlight Excellent
======================================================= */
document.getElementById("highlightExcellentBtn").onclick = function () {
    const tbody = getTbody();
    for (let row of tbody.rows) {
        const { absences } = computeRowCounts(row);
        if (absences < 3) row.style.outline = "3px solid #34A853";
        else row.style.outline = "";
    }
};

/* =======================================================
   EXO 6 — Reset Colors
======================================================= */
document.getElementById("resetColorsBtn").onclick = function () {
    const tbody = getTbody();
    for (let row of tbody.rows) {
        row.classList.remove("row-green", "row-yellow", "row-red");
        row.style.outline = "";
        row.cells[16].textContent = "";
    }
};

/* =======================================================
   EXO 7 — Search
======================================================= */
document.getElementById("searchInput").addEventListener("keyup", function () {
    const q = this.value.toLowerCase();
    const rows = getTbody().rows;

    for (let r of rows) {
        const last = r.cells[1].textContent.toLowerCase();
        const first = r.cells[2].textContent.toLowerCase();
        r.style.display = (first.includes(q) || last.includes(q)) ? "" : "none";
    }
});

/* =======================================================
   EXO 7 — Sorting
======================================================= */
document.getElementById("sortAbsencesBtn").onclick = function () {
    const tbody = getTbody();
    const rows = Array.from(tbody.rows);

    rows.sort((a, b) => {
        const A = computeRowCounts(a).absences;
        const B = computeRowCounts(b).absences;
        return A - B;
    });

    rows.forEach(r => tbody.appendChild(r));
    sortMessage.textContent = "Sorted by absences (ascending)";
};

document.getElementById("sortParticipationBtn").onclick = function () {
    const tbody = getTbody();
    const rows = Array.from(tbody.rows);

    rows.sort((a, b) => {
        const A = computeRowCounts(a).participation;
        const B = computeRowCounts(b).participation;
        return B - A;
    });

    rows.forEach(r => tbody.appendChild(r));
    sortMessage.textContent = "Sorted by participation (descending)";
};

/* =======================================================
   LOGOUT
======================================================= */
document.getElementById("logoutBtn").onclick = () => {
    alert("You have been logged out.");
};

